#include "fs/operations.h"
#include <assert.h>
#include <string.h>
#include <unistd.h>

int main() {

    char input[10241];
    memset(input, 'A', 10240);

    char buffer[2048];

         
    char *path = "/f1";
    assert(tfs_init() != -1);

    int file = tfs_open(path, TFS_O_CREAT);


    printf("%ld",tfs_write(file, input, 4096));
    printf("%ld",tfs_read(file, buffer, 2048));



    return 0;
}